# Tiny-Detectron

Minimal object-detection training project for the ML-Dive demo.

## Setup
```bash
pip install -r requirements.txt
python train.py --config configs/base.yaml
```
