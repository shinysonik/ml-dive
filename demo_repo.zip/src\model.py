class Detector:
    def step(self): return 0.5
