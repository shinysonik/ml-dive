import torch
from src.model import Detector

def train(cfg):
    model = Detector()
    opt = torch.optim.SGD(model.parameters(), lr=cfg["lr"])
    # training loop
    for epoch in range(cfg["epochs"]):
        loss = model.step()
        print(f"epoch {epoch} loss {loss}")
